﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphictoriaRouter
{
    class miscFunctions
    {
        public static string serverIP = "127.0.0.1";
        public static void writeLine(string text, int classID)
        {
            if (classID == 0) Console.WriteLine("[Graphictoria Router] " + text);
            if (classID == 1) Console.WriteLine("[ServerThread] " + text);
        }
    }
}
