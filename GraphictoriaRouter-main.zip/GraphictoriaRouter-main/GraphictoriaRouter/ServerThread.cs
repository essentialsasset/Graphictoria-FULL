﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Net;
using System.IO;
using System.Linq;

namespace GraphictoriaRouter
{
    public class ServerThread
    {
        public static void createServer(string placeURL, string serverVersion, string creator_userID, string gameName, string gameDescription, string gamePrivacy)
        {
            WebClient wClient = new WebClient();
            string serverInfo = "";
            int serverPort = randomizeServerPort();

            string[] serverInfoArray;
            string serverID;
            try
            {
                miscFunctions.writeLine("Sending createServer request to API [Version = " + serverVersion + "] [UserID = " + creator_userID + "]", 1);
                serverInfo = wClient.DownloadString("http://api.xdiscuss.net/router/createServer.php?version=" + serverVersion + "&userID=" + creator_userID + "&key=UEJ0ekt1WF9nbGJmM31GLStVfE5TSlIsYzI-MzpqN08oLi9-azpxMGtFZi1fJW9PWXlvYi5sW1RWXlVuYyRV&serverName=" + gameName + "&serverDescription=" + gameDescription + "&serverPrivacy=" + gamePrivacy + "&ip=" + miscFunctions.serverIP + "&port=" + serverPort + "&placeURL=" + placeURL);
            }
            catch (Exception)
            {
                miscFunctions.writeLine("Failed to create server", 1);
                Thread.CurrentThread.Abort();
            }

            miscFunctions.writeLine("Created new serverThread [Version = " + serverVersion + "]", 1);
            Process mainProcess;
            try
            {
                Console.WriteLine(serverInfo);
                serverInfoArray = serverInfo.Split('-');
                serverID = serverInfoArray[0];
                serverClass._serverPrivateKey.Value = serverInfoArray[1];

                string procPath = "";
                procPath = Directory.GetCurrentDirectory() + "//" + serverVersion + "//Server" + serverVersion + ".exe";

                ProcessStartInfo GraphictoriaServer = new ProcessStartInfo(procPath);
                GraphictoriaServer.WindowStyle = ProcessWindowStyle.Hidden;
                GraphictoriaServer.Arguments = "-no3d -script dofile('http://api.xdiscuss.net/serverscripts/server.php?key=" + serverClass._serverPrivateKey.Value + "&dedicated=true&port=" + serverPort + "&placeURL=" + placeURL + "');";
                miscFunctions.writeLine("[" + serverPort + "] Starting  (" + procPath + ")", 1);
                mainProcess = Process.Start(GraphictoriaServer);
                serverClass._processID.Value = mainProcess.Id;
                mainProcess.WaitForInputIdle();
                miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Server started (" + placeURL + ") (Process ID = " + serverClass._processID.Value + ")", 1);
                Thread.Sleep(1000 * 60 * 5); // Five minutes so that a player can join the server
                miscFunctions.writeLine("[" + serverPort + "] (Process ID = " + serverClass._processID.Value + ") Checking if there is any player", 1);
                string placeHash = placeURL.Replace("http://xdiscuss.net/data/assets/uploads/", "");
                miscFunctions.writeLine("[" + serverPort + "] Deleting place file hash (" + placeHash + ")", 1);
                string delPlaceRes = wClient.DownloadString("http://api.xdiscuss.net/router/deletePlace.php?hash=" + placeHash);
                miscFunctions.writeLine("[" + serverPort + "] Delete place result : " + delPlaceRes, 1);
                while (mainProcess.HasExited == false)
                {
                    Thread.Sleep(5000);
                    string numPlayersString = wClient.DownloadString("http://api.xdiscuss.net/router/getPlayerCount.php?serverKey=" + serverClass._serverPrivateKey.Value);
                    if (numPlayersString == "0")
                    {
                        string delResult = wClient.DownloadString("http://api.xdiscuss.net/router/deleteServer.php?serverKey=" + serverClass._serverPrivateKey.Value + "&key=UEJ0ekt1WF9nbGJmM31GLStVfE5TSlIsYzI-MzpqN08oLi9-azpxMGtFZi1fJW9PWXlvYi5sW1RWXlVuYyRV");
                        if (delResult == "success")
                            miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Deleted from website (Process ID = " + serverClass._processID.Value + ")", 1);
                        if (delResult == "not-found")
                            miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Was already deleted from the website (Process ID = " + serverClass._processID.Value + ")", 1);
                        miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Shutting down (Process ID = " + serverClass._processID.Value + ")", 1);
                        Process.GetProcessById(serverClass._processID.Value).Kill();
                    }
                }
                if (mainProcess.HasExited)
                    miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] The server has been closed successfully", 1);
                miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Killing serverThread", 1);
                Process.GetProcessById(serverClass._processID.Value).Kill();
                wClient.Dispose();
                Thread.CurrentThread.Abort();
            }
            catch (Exception)
            {
                try
                {
                    // This should always run since no exceptions can possibly occur here.
                    string delResult = wClient.DownloadString("http://api.xdiscuss.net/router/deleteServer.php?serverKey=" + serverClass._serverPrivateKey.Value + "&key=UEJ0ekt1WF9nbGJmM31GLStVfE5TSlIsYzI-MzpqN08oLi9-azpxMGtFZi1fJW9PWXlvYi5sW1RWXlVuYyRV");
                    if (delResult == "success")
                        miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Deleted from website (Process ID = " + serverClass._processID.Value + ")", 1);
                    if (delResult == "not-found")
                        miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Was already deleted from the website, oops! (Process ID = " + serverClass._processID.Value + ")", 1);

                    // Exception can occur here
                    Process.GetProcessById(serverClass._processID.Value).Kill();
                }
                catch (Exception) {
                    miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Exception attempted to kill server, not running", 1);
                }
                miscFunctions.writeLine("[" + serverPort + "] [" + serverClass._serverPrivateKey.Value + "] Killing serverThread after attempt #2", 1);
                wClient.Dispose();
                Thread.CurrentThread.Abort();
            }
        }
        public static int randomizeServerPort()
        {
            var startingAtPort = 10000;
            var maxNumberOfPortsToCheck = 50000;
            var range = Enumerable.Range(startingAtPort, maxNumberOfPortsToCheck);
            var portsInUse =
                from p in range
                join used in System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().GetActiveUdpListeners()
            on p equals used.Port
                select p;

            var FirstFreeUDPPortInRange = range.Except(portsInUse).FirstOrDefault();
            if (FirstFreeUDPPortInRange > 0)
            {
                return FirstFreeUDPPortInRange;
            }
            else
                miscFunctions.writeLine("No open port!", 0);
            Thread.CurrentThread.Abort();
            return 0;
        }
    }
}
