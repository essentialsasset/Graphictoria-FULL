﻿using System.Threading;

namespace GraphictoriaRouter
{
    class serverClass
    {
        public static ThreadLocal<string> _serverPrivateKey = new ThreadLocal<string>(() => {
            return "";
        });

        public static ThreadLocal<int> _processID = new ThreadLocal<int>(() => {
            return 0;
        });
    }
}
