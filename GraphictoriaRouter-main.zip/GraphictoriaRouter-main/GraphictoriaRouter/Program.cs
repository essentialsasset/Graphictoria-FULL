﻿using System;
using System.Net;
using System.Threading;

namespace GraphictoriaRouter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Graphictoria Server Router";
            miscFunctions.writeLine("Starting Graphictoria Server Router", 0);
            try
            {
                WebClient wClient = new WebClient();
                miscFunctions.serverIP = wClient.DownloadString("http://api.xdiscuss.net/router/getIP.php?key=UEJ0ekt1WF9nbGJmM31GLStVfE5TSlIsYzI-MzpqN08oLi9-azpxMGtFZi1fJW9PWXlvYi5sW1RWXlVuYyRV");
                miscFunctions.writeLine("[" + miscFunctions.serverIP + "] Graphictoria Server Router Started", 0);
                checkRequest();
            }
            catch(Exception)
            {
                miscFunctions.writeLine("Unable to start the router!", 0);
                Console.ReadKey();
            }
        }

        public static void checkRequest()
        {
            WebClient wClient = new WebClient();
            while (true)
            {
                Thread.Sleep(1000);
                try
                {
                    string apiResults = wClient.DownloadString("http://api.xdiscuss.net/router/getRequests.php?key=UEJ0ekt1WF9nbGJmM31GLStVfE5TSlIsYzI-MzpqN08oLi9-azpxMGtFZi1fJW9PWXlvYi5sW1RWXlVuYyRV");
                    if (apiResults != "no-request")
                    {
                        string[] apiResultsArray = apiResults.Split('-');
                        string gameLocation = apiResultsArray[0];       // Place location, used to load the place itself
                        string serverVersion = apiResultsArray[1];      // Server version, such as 2008 or 2009
                        string creator_userID = apiResultsArray[2];     // Creator userID
                        string gameName = apiResultsArray[3];           // Server name
                        string gameDescription = apiResultsArray[4];    // Server description
                        string gamePrivacy = apiResultsArray[5];        // Game privacy type
                        Thread sThread = new Thread(() => ServerThread.createServer(gameLocation, serverVersion, creator_userID, gameName, gameDescription, gamePrivacy));
                        sThread.Start();
                    }
                }
                catch (Exception)
                {
                    miscFunctions.writeLine("Unable to reach Graphictoria. Trying again.", 0);
                }
            }
        }
    }
}
