### Graphictoria Router
Used to create game servers on demand
