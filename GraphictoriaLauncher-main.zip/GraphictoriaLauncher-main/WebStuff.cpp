#include <Windows.h>
#include <string>
#include <stdio.h>
#include <WinInet.h>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

#include "WebStuff.h"

std::string getURL(const char* URL) {
	DeleteUrlCacheEntryA(URL);
    
    /* Lmao, Raymonf thought we stole his code because of this string. Absolute cringe. */
	HINTERNET interwebs = InternetOpenA("Graphictoria/1.0 (Launcher)", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, NULL);
	HINTERNET urlFile;
	std::string rtn;
	if (interwebs) {
		urlFile = InternetOpenUrlA(interwebs, URL, NULL, NULL, NULL, NULL);
		if (urlFile) {
			char buffer[2000];
			DWORD bytesRead;
			do {
				InternetReadFile(urlFile, buffer, 2000, &bytesRead);
				rtn.append(buffer, bytesRead);
				memset(buffer, 0, 2000);
			} while (bytesRead);
			InternetCloseHandle(interwebs);
			InternetCloseHandle(urlFile);
			return rtn;
		}
	}
	InternetCloseHandle(interwebs);
	return rtn;
}
