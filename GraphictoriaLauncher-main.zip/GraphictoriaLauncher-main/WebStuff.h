#include <Windows.h>
#include <string>

#pragma comment(lib, "Wininet.lib")


std::string getURL(const char* URL);