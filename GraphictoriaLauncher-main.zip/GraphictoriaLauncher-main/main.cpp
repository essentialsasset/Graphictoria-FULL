#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <ctype.h>
#include <conio.h>
#include <ostream>
#include <sstream>
#include <algorithm>
#include <TlHelp32.h>
#include <urlmon.h>
#include <WinInet.h>
#include <VMProtectSDK.h>
#include "WebStuff.h"
#include "md5.h"

#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "wininet.lib")

#define pause() printf("Press any key to continue . . ."); _getch()
#define VERSION "4.6.2"
#define DLL_VERSION "2"

std::vector<std::string> SplitString(const char *str, char c)
{
	VMProtectBeginUltra("Split");
	std::vector<std::string> result;
	do {
		const char *begin = str;
		while (*str != c && *str) {
			str++;
		}
		result.push_back(std::string(begin, str));
	} while (0 != *str++);
	VMProtectEnd();
	return result;
}

std::string GetModulePath(std::string ModuleName)
{
	VMProtectBeginUltra("GetModulePath");
	char buff[MAX_PATH];
	GetModuleFileNameA(GetModuleHandleA(ModuleName.c_str()), buff, MAX_PATH);
	VMProtectEnd();
	return std::string(buff).erase(std::string(buff).find(ModuleName), std::string(buff).length());
}

BOOL LoadLibEx(HANDLE Process, const char* DLL)
{
	VMProtectBeginUltra("Inject");
	void* RemoteString = VirtualAllocEx(Process, NULL, strlen(DLL), MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
	WriteProcessMemory(Process, RemoteString, DLL, strlen(DLL), NULL);
	HANDLE hThread = CreateRemoteThread(Process, NULL, NULL, (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleA("Kernel32.dll"), "LoadLibraryA"), RemoteString, NULL, NULL);
	WaitForSingleObject(hThread, -1);
	DWORD eCode;
	GetExitCodeThread(hThread, &eCode);
	VMProtectEnd();
	if (hThread == INVALID_HANDLE_VALUE || eCode == 0) return FALSE;
	return TRUE;
}

inline bool exists(const std::string& name) {
	struct stat buffer;
	return (stat(name.c_str(), &buffer) == 0);
}

const char* ErrorToString(DWORD error)
{
	switch (error)
	{
	case ERROR_FILE_NOT_FOUND: return "ERROR_FILE_NOT_FOUND";
	case ERROR_ACCESS_DENIED: return "ERROR_ACCESS_DENED";
	}
}

int main(int argc, char *argv[])
{
	SetConsoleTitle("Graphictoria");
	std::cout << "Graphictoria 2009 Launcher (Version " << VERSION << ")" << std::endl;

	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(PROCESSENTRY32);

	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (Process32First(snapshot, &entry) == TRUE)
	{
		while (Process32Next(snapshot, &entry) == TRUE)
		{
			if (strcmp(entry.szExeFile, "Client.exe") == 0)
			{
				HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, entry.th32ProcessID);
				if (hProcess)
				{
					TerminateProcess(hProcess, 0);
					CloseHandle(hProcess);
				}
				else
				{
					std::cout << "Failed to open process!" << std::endl;
					pause();
					return 1;
				}
			}
		}
	}
	CloseHandle(snapshot);

	if (argc != 2)
	{
		std::cout << "Invalid parameters. Did you use the Games page?" << std::endl;
		pause();
		return 1;
	}
	else
	{
		std::string argsClean = argv[1];
		argsClean.erase(std::remove(argsClean.begin(), argsClean.end(), '/'), argsClean.end());
		argsClean.erase(std::remove(argsClean.begin(), argsClean.end(), ':'), argsClean.end());
		std::string removethis = "graphictoriaclient";
		argsClean.erase(argsClean.find("graphictoriaclient"), removethis.length()); //too lazy to get the length

		std::vector<std::string>params = SplitString(argsClean.c_str(), ';');
		if (params.size() != 3)
		{
			std::cout << "Invalid parameters." << std::endl;
			pause();
			return 1;
		}

		std::string userkey = params[0];
		std::string gameId = params[1];
		std::string userId = params[2];

		std::string body = getURL(std::string("http://api.xdiscuss.net/launcher/security.php?key=" + userkey + "&uid=" + userId + "&gameId=" + gameId).c_str());
		std::string version = getURL("http://api.xdiscuss.net/launcher/version.txt");

		if (strcmp(version.c_str(), VERSION) != 0)
		{
			VMProtectBeginUltra("update");
			std::cout << VMProtectDecryptStringA("This version of Graphictoria has been outdated! Downloading the newest installer...") << std::endl;
			if (!exists(VMProtectDecryptStringA(std::string(std::string(getenv(VMProtectDecryptStringA("LocalAppData"))) + VMProtectDecryptStringA("\\GT\\")).c_str())))CreateDirectory(std::string(std::string(getenv(VMProtectDecryptStringA("LocalAppData"))) + VMProtectDecryptStringA("\\GT\\")).c_str(), NULL);
			std::string file = getenv(VMProtectDecryptStringA("LocalAppData"));
			file += VMProtectDecryptStringA("\\GT\\Graphictoria2009.exe");
			if (exists(file))remove(file.c_str());
			const char* ur1 = VMProtectDecryptStringA("https://gtdownloadhandler:publicpasswordfordownload@api.xdiscuss.net/downloads/Graphictoria2009_installer.exe");
			const char* filePath = VMProtectDecryptStringA(file.c_str());
			DeleteUrlCacheEntry(ur1);
			HRESULT download = URLDownloadToFile(NULL, ur1, filePath, NULL, NULL);
			if (SUCCEEDED(download))
			{
				SHELLEXECUTEINFO shExecInfo;
				shExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
				shExecInfo.fMask = NULL;
				shExecInfo.hwnd = NULL;
				shExecInfo.lpVerb = "runas";
				shExecInfo.lpFile = file.c_str();
				shExecInfo.lpParameters = NULL;
				shExecInfo.lpDirectory = NULL;
				shExecInfo.nShow = SW_NORMAL;
				shExecInfo.hInstApp = NULL;
				ShellExecuteEx(&shExecInfo);
				VMProtectEnd();
				return 0;
			}
			else
			{
				std::cout << VMProtectDecryptStringA("Unknown error occurred!") << std::endl;
				pause();
				return 1;
			}
		}

		if (body != "yes")
		{
			std::cout << "Authentication has failed. Please try logging in again, if that does not help, please reach out to the forums." << std::endl;
			pause();
			return 1;
		}
		else
		{
			std::cout << "Launching..." << std::endl;
			VMProtectBeginUltra("hi");
			std::string folder = getenv(VMProtectDecryptStringA("LocalAppData"));
			folder += VMProtectDecryptStringA("\\GT\\");
			std::string DLL = getenv(VMProtectDecryptStringA("LocalAppData"));
			DLL += VMProtectDecryptStringA("\\GT\\Graphictoria2.dll");
			if (!exists(VMProtectDecryptStringA(DLL.c_str())))
			{
				CreateDirectory(VMProtectDecryptStringA(folder.c_str()), NULL);
				const char* ur1 = VMProtectDecryptStringA("https://gtdownloadhandler:publicpasswordfordownload@api.xdiscuss.net/downloads/2009/Graphictoria2.dll");
				const char* filePath = VMProtectDecryptStringA(DLL.c_str());
				DeleteUrlCacheEntry(ur1);
				HRESULT download = URLDownloadToFile(NULL, ur1, filePath, NULL, NULL);
				if (!SUCCEEDED(download))
				{
					std::cout << VMProtectDecryptStringA("Unknown error occurred!") << std::endl;
					pause();
					VMProtectEnd();
					return 1;
				}
			}

			VMProtectBeginUltra("hi2");

			std::string url = VMProtectDecryptStringA("http://api.xdiscuss.net/user/game/joinGameV2.php?userID=") + userId + VMProtectDecryptStringA("&gameID=") + gameId + VMProtectDecryptStringA("&key=") + userkey;
			std::string param = std::string("-TATVv4QZvP \"loadfile('" + url + "')()\"");

			PROCESS_INFORMATION ProcessInfo;
			STARTUPINFO StartupInfo;
			ZeroMemory(&StartupInfo, sizeof(StartupInfo));
			StartupInfo.cb = sizeof StartupInfo;

			std::string filepath = GetModulePath(VMProtectDecryptStringA("GraphictoriaLauncher.exe")) + VMProtectDecryptStringA("Client.exe");

			std::string newargs = filepath + " " + param;

			if (CreateProcess(filepath.c_str(), (char*)newargs.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &StartupInfo, &ProcessInfo))
			{
				while (true)
				{
					HWND hWnd = FindWindow(NULL, VMProtectDecryptStringA("Graphictoria - [Place1]"));
					if (hWnd)
					{
						LONG style = GetWindowLong(FindWindow(NULL, VMProtectDecryptStringA("Graphictoria - [Place1]")), GWL_STYLE);
						if (style && IsWindowVisible(hWnd))
							break;
					}
					Sleep(10);
				}
				if (!LoadLibEx(ProcessInfo.hProcess, DLL.c_str()))
				{
					TerminateProcess(ProcessInfo.hProcess, 0);
					CloseHandle(ProcessInfo.hProcess);
					CloseHandle(ProcessInfo.hThread);
					std::cout << VMProtectDecryptStringA("Unknown error occurred!") << std::endl;
					pause();
					VMProtectEnd();
					return 1;
				}
				CloseHandle(ProcessInfo.hProcess);
				CloseHandle(ProcessInfo.hThread);
			}
			else
			{
				std::cout << VMProtectDecryptStringA("Failed to launch Graphictoria!") << std::endl;
				pause();
				return 1;
			}
		}
	}
	return 0;
}