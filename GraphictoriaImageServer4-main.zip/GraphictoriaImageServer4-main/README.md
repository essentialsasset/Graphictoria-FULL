### Graphictoria Image Server
Used to render thumbnails for the website. Just use RCCService instead of this.
