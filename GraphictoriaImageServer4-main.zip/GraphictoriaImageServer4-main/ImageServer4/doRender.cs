﻿using System;
using System.Diagnostics;
using System.Net;
using System.Threading;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.IO;
using Renci.SshNet;

namespace ImageServer4
{
    class doRender
    {
        public static void executeLua(string command)
        {
            Program.writeLine("Executing lua (" + command + ")", 1);
            Process luaProc = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "lua.exe",
                    Arguments = "\"" + command + "\"",
                    WindowStyle = ProcessWindowStyle.Hidden

                }
            };
            luaProc.Start();
            luaProc.WaitForExit();
        }

        public static Bitmap ResizeImage(Image image, int width, int height)
        {
            Rectangle destRect = new Rectangle(0, 0, width, height);
            Bitmap bitmap = new Bitmap(width, height);
            bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                using (ImageAttributes imageAttributes = new ImageAttributes())
                {
                    imageAttributes.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, imageAttributes);
                }
            }
            image.Dispose();
            return bitmap;
        }

        public static void takeScreenshot(string renderType, string render_id)
        {
            int width = Screen.PrimaryScreen.Bounds.Width - 600;
            int height = Screen.PrimaryScreen.Bounds.Height - 250;
            int sourceX = 200;
            int sourceY = 124;

            Bitmap bitmap = new Bitmap(width, height);
            Graphics graphics = Graphics.FromImage(bitmap);
            graphics.CopyFromScreen(sourceX, sourceY, 0, 0, bitmap.Size, CopyPixelOperation.SourceCopy);

            if (renderType != "server") bitmap.MakeTransparent(bitmap.GetPixel(0, 0));

            Bitmap bitmap2 = ResizeImage(bitmap, 300, 300);
            bitmap.Dispose();
            if (renderType == "character") renderType = "user";

            bitmap2.Save(@"C://xampp//htdocs//"+ renderType + "/" + render_id + ".png", ImageFormat.Png);
            bitmap2.Dispose();
        }

        public static void render(string webString, WebClient wClient)
        {
            Console.WriteLine("Rendering...");
            string[] stringArray = webString.Split('-');
            string render_id = stringArray[0];
            string renderType = stringArray[1];

            string scriptLocation = "http://api.xdiscuss.net/img/" + renderType + "v2.php?id=" + render_id;
            executeLua("dofile('" + scriptLocation + "&t49=' .. tick())");

            if (renderType != "server")
            {
                ProcessStartInfo clickService = new ProcessStartInfo("ClickS");
                clickService.WindowStyle = ProcessWindowStyle.Hidden;
                Process clickServiceProc = Process.Start(clickService);
                clickServiceProc.Start();
            }

            Thread.Sleep(4000);
            takeScreenshot(renderType, render_id);

            if (renderType != "server")
            { 
                Process[] processesByName = Process.GetProcessesByName("ClickS");
                for (int i = 0; i < processesByName.Length; i++)
                {
                    Process process = processesByName[i];
                    process.Kill();
                }
            }
            if (renderType != "server") executeLua("game.Workspace.Player.Parent = nil");
            executeLua("dofile('http://api.xdiscuss.net/img/clearServer.lua')");

            string ftype = renderType;
            if (renderType == "character") ftype = "user";

            Console.WriteLine("Uploading...");
            var fileStream = new FileStream(@"C:/xampp/htdocs/" + ftype + "/" + render_id + ".png", FileMode.Open);
            var ftpClient = new SftpClient("g_api.local", 22, "r", "");
            ftpClient.Connect();
            if (fileStream != null) ftpClient.UploadFile(fileStream, "/var/www/api/imageServer/" + ftype + "/" + render_id + ".png", null);
            ftpClient.Disconnect();
            fileStream.Close();
            fileStream.Dispose();
            File.Delete(@"C:/xampp/htdocs/" + ftype + "/" + render_id + ".png");
            wClient.DownloadString(string.Concat(new string[]
            {
                "http://api.xdiscuss.net/img/doFinish.php?renderid=",
                render_id,
                "&type=",
                renderType,
                "&apiKey=DebianIsAHotFuckingChickAndRaymonfNeedsToDie342908590498590485"
            }));
        }
    }
}
