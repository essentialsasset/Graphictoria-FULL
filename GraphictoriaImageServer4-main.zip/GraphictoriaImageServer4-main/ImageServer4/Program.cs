﻿using System;
using System.Threading;
using System.Net;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace ImageServer4
{
    class Program
    {
        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("kernel32.dll")]
        private static extern IntPtr GetConsoleWindow();

        public static void writeLine(string text, int classId)
        {
            if (classId == 0) Console.WriteLine("[ImageServer] " + text);
            if (classId == 1) Console.WriteLine("[Render] " + text);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("[ImageServer] Starting client used for rendering...");
            Console.Title = "Graphictoria ImageServer";

            Process[] processesByName = Process.GetProcessesByName("tv_w32");
            for (int i = 0; i < processesByName.Length; i++)
            {
                Process process = processesByName[i];
                //process.Kill();
            }
            Process[] processesByName2 = Process.GetProcessesByName("tv_x64");
            for (int j = 0; j < processesByName2.Length; j++)
            {
                Process process2 = processesByName2[j];
                //process2.Kill();
            }
            Process[] processesByName3 = Process.GetProcessesByName("TeamViewer_Desktop");
            for (int k = 0; k < processesByName3.Length; k++)
            {
                Process process3 = processesByName3[k];
                //process3.Kill();
            }
            Process[] processesByName4 = Process.GetProcessesByName("TeamViewer");
            for (int l = 0; l < processesByName4.Length; l++)
            {
                Process process4 = processesByName4[l];
                //process4.Kill();
            }

            if (!File.Exists("render.exe"))
            {
                writeLine("Client not found!", 0);
                Console.ReadKey();
                Environment.Exit(0);
            }

            Process serverProc = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "render.exe",
                    Arguments = "-script dofile('http://api.xdiscuss.net/img/imageStart.lua');"
                }
            };
            serverProc.Start();
            serverProc.WaitForInputIdle();
            //ShowWindow(GetConsoleWindow(), 0);
            WebClient wClient = new WebClient();
            while (true)
            {
                Thread.Sleep(1000);
                string currentQueue = wClient.DownloadString("http://api.xdiscuss.net/img/getList.php");
                if (currentQueue != "no-render") doRender.render(currentQueue, wClient);
                else writeLine("No render found. Checking again in 1 second.", 0);
            }
        }
    }
}
